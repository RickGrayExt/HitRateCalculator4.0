Place your dataset CSV here named DataSetClean.csv
Expected columns: sku_id,units,orders,velocity,seasonal,category
